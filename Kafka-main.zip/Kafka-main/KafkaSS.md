![Ekran görüntüsü 2023-12-27 012136](https://github.com/ErayKeles/Kafka/assets/128937269/131fc840-69c7-481e-a4d5-78dbc0b331b0)
![Ekran görüntüsü 2023-12-27 011956](https://github.com/ErayKeles/Kafka/assets/128937269/13c8f645-6514-4935-8871-a9bf2e64a431)
![Ekran görüntüsü 2023-12-27 012121](https://github.com/ErayKeles/Kafka/assets/128937269/cabb2351-8542-4dec-9367-19d5a4b5c43f)
![Ekran görüntüsü 2023-12-27 003111](https://github.com/ErayKeles/Kafka/assets/128937269/cadbeef4-a44f-4543-9aca-790ce7bd062c)
